# User Validation Web App

A simple login web application built with **Flask** and **SQLite**.

The user submits a login name and password. The server checks them against
the data stored in the database:

- ✅ Match → a **successful login** page is returned
- ❌ No match → a **failure message** is shown on the login page

## Features
- Passwords stored as salted hashes (never plain text)
- Parameterized SQL queries (protects against SQL injection)
- Database auto-created with sample users on first run

## Project Structure
```
user-validation-app/
├── app.py            # Flask app & login logic
├── init_db.py        # Creates DB + sample users
├── requirements.txt
├── templates/
│   ├── login.html    # Login form (shows error on failure)
│   └── success.html  # Shown after successful login
└── README.md
```

## Run Locally
```bash
git clone https://github.com/<your-username>/user-validation-app.git
cd user-validation-app

python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000

## Sample Credentials
| Username | Password   |
|----------|------------|
| admin    | admin123   |
| alice    | alice@2026 |

## Tech Stack
Python · Flask · SQLite · HTML/CSS

## License
MIT
