"""Simple user validation web app (Flask + SQLite)."""
import os
import sqlite3

from flask import Flask, render_template, request

from init_db import DB_PATH, init_db

app = Flask(__name__)

# Create the database automatically on first run
if not os.path.exists(DB_PATH):
    init_db()


def get_user(username):
    """Fetch a user row from the database (parameterized query -> no SQL injection)."""
    conn = sqlite3.connect(DB_PATH)
    try:
        return conn.execute(
            "SELECT username, password_hash FROM users WHERE username = ?",
            (username,),
        ).fetchone()
    finally:
        conn.close()


@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        from werkzeug.security import check_password_hash

        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        user = get_user(username)
        if user and check_password_hash(user[1], password):
            return render_template("success.html", username=user[0])

        return render_template("login.html", error="Invalid username or password."), 401

    return render_template("login.html", error=None)


if __name__ == "__main__":
    app.run(debug=True)
